<template>
 <div>
   <Search></Search>
   <Ongoing :name="name"></Ongoing>
   <h2>Completed List Of Tasks</h2>
  <Completed></Completed>
  </div>
</template>

<script>
import Ongoing from './components/Ongoing.vue'
import Search from './components/Search.vue'
import Completed from './components/Completed.vue'

//let ifStorageExists = false ; 

export default {
  name: 'App',
  components: {
    Search,
    Ongoing ,
    Completed ,
   } , 
   
   data() {
     return {
        taskid : 1000 ,
        name : '', 
        desc:'' , 
        start: '' , 
        end : '' , 
        completed: false ,
        people:'' , 

     }
   } , 

  methods: {
       
  } ,

  computed : {

     lsUpdate() {
        if(!localStorage.getItem('tt')) {
          localStorage.setItem('tt' , {taskid : this.taskid , name : '' , start: '' , end : '' , completed: false , });
        console.log('Database created') ; 
        }
        return true ; 
     } ,
  }

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
  display: grid;
  place-items: center ;
}

.container {
  width:95vw ; 
  margin: 0 auto ;
}

h1{
  font-size: 3.5rem;
}
h2 {
  font-size:2.5rem;
}

.tt-atom-btn  {
  background-color:#3ca6d3;
  border: none; 
  height: 40px;
  min-width:69px;
  padding: 10px;
  color: white;
  font-size: 19px ;
  font-weight: 400 ;
}

button{
  cursor: pointer ; 
}

[v-cloak] {
  display: none; 
}

#tasks-collection{
  height:200px ; border :1px solid red ; 
  overflow-y: scroll;
}
</style>
