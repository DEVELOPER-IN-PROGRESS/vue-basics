<template>
     
   <div class="task-container" v-cloak>
       
        <div class="table-container">
         <table border="1">
        <tr>
            <th>Task#ID</th>
            <th>Task Name</th>
            <th  >Description</th>
            <th >Start Date</th>
            <th >End Date</th>
            <th >Assignees</th>
        </tr>
        <tr style="height:50px;">
            <td width="70px" >{{ taskid }}</td>
            <td> {{name}} </td>
            <td rowspan="4" style="word-wrap:break-word;overflow-y:scroll;" width="350px" valign="top">{{ desc}}
            </td>
            <td width="95px"  > {{start }}</td>
            <td width="95px"  >{{end}}</td>
            <td rowspan="4" style="word-wrap:break-word;overflow-y:scroll;" width="200px" valign="top"> {{ people }}</td>
         </tr>
         </table>
    </div>
   
    <div class="buttons-container">
       <button href="#" @click="demo"  class="tt-atom-btn">
        Edit 
    </button> 

    <button href="#"  class="tt-atom-btn complete">
        Mark as complete
    </button>

    </div>


   </div>
</template>

<script>
  export default{
      name: 'Ongoing' , 
      props: ['age' , 'name' , 'taskid' , ] ,
      data() {
          return{

          }
      },
         methods: {
            demo(){
                alert('HI') ; 
            }
      }
  }  
</script>

<style scoped>
    table {
        width:100% ; 
        align-content:left ; 
    }

    /* td, th , tr{
        border :1px dashed black ; 
    } */

.complete {
    background-color:#41b883;
    font-size: 15px;
    padding: 4px    ;
}

.buttons-container{
    display: flex;
    flex-direction: row ;
 }

 .buttons-container > button {
     margin : 5px 10px; 
 }

 .task-container {
    display: grid;
    grid-template-columns: 5fr 1fr;
    grid-gap: 10px;
    /* border:1px solid red ;  */
    margin:2px 0px; 
    align-items: center;
 }
</style>