<template>

      <div class="table-container">
       <div>
         <table border="1">
        <tr>
            <th>Task#ID</th>
            <th>Task Name</th>
            <th  >Description</th>
            <th >Start Date</th>
            <th >End Date</th>
            <th >Assignees </th>
            <th >STATUS</th>
        </tr>
        <tr  style="height:60px;">
            <td width="70px" >{{  }}</td>
            <td  >{{  }}</td>
            <td  width="350px" valign="top">{{  }}
            </td>
            <td width="95px"  >{{  }}</td>
            <td width="95px"  > {{ }} </td>
            <td width="120px"  >{{ }} </td>
            <td  style="word-wrap:break-word;overflow-y:scroll;" width="200px" > {{  }}  </td>
        </tr>
         </table>
       </div>
    </div>
   
</template>

<script>
export default {
    name: 'Searchresult' , 

    data() {
        return {

        }
    }, 



}
</script>
<style scoped>
 table {
        width:  90vw ;
        align-content:left ; 
    }

    .table-container{
        display:grid ;
        grid-template-columns: 5fr;
        height: 90px ;
        overflow-y: scroll;
        margin-bottom: 20px;

    }
</style>