<template>
  <div >
    <div>
    <h1>Time Task Clone</h1>
    
    <div id="search-bar" class="search">
      <label for="options">search by :</label>
      <select name="options" v-model="selected" @change="demo()">
        <option value="taskid">task-id</option>
        <option value="name">task-name</option>
        <option value="person">person</option>
      </select>

      <form >
  <input v-if="this.searchtype === 'number'"  placeholder="Search with taskid" type="number" v-model="taskid" min="1000" @input="handleNum"/>
        <input v-else-if="  this.searchtype === 'tname'"  placeholder="Search with taskname"  type="text" v-model="name"  @input="handle"/> 
            <input v-else  placeholder="Search with person" type="text" v-model="people"  @input="handle"/> 
              <input type="submit"  />
        </form>
 <!-- //return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || (event.charCode==32) -->
 
     
    </div>  
  </div>
     <button @click="$emit('openform')" href="#" class="tt-atom-btn  add" >
        Add Task
      </button>
           <p>name :{{ name }}  people: {{people }}    taskid :{{ taskid}}:: Search results :: </p>

      <searchresult></searchresult>
  </div>    
</template>

<script>
import Searchresult from './Searchresult.vue';

export default {
  name: "Search",
  components : {
    Searchresult,
  } ,

  props: ['db'] , 

  data() {
    return {
      name: '',
      people: '',
      taskid: 0,
      searchtype:'number' , 


      person:true ,
      returnItem: {},
    };
  },

  emits: ['openform'],

  methods: {

    demo() {
 
      switch(this.selected){
        case 'taskid':  this.searchtype = 'number' ; break ; 

        case 'name':   this.searchtype = 'tname' ; break ; 
          
        case 'person':    this.searchtype = 'person' ; break ; 
      }

 console.log('Searchtype' ,  this.searchtype ) ; 
      
   

      },


     

    handle(e){
        let searchString = e.target.value ; 
        searchString = searchString.toLowerCase() ;
        console.log("S = " , searchString);   

        console.log('people' , this.people);
        console.log('name', this.name); 

        if(this.people != ''){
           this.filterDb('people', searchString ) ;
        }
        else {
          this.filterDb('name' , searchString) ; 
        }
          
    },

    

      handleNum(e){
        let k =  e.target.value
        console.log("num= " , k);
        
        k = Number(k);
      console.log(k);
         this.filterDb('taskid',  k) ;
       } ,

      filterDb( key , value ){
        if(key==='taskid'){
             this.db.filter( item => { 
          if(item.taskid === value )
          { 
            this.returnItem =item ;
             }
        
        })
        }

        else if(key==='people'){
          this.db.filter ( item =>  {  if(item.people.toLowerCase().search(`${value}`) ){ 
             
             this.returnItem =item ;
            }               
          })
        }
        
        else {
           this.db.filter ( item =>  {  if(item.name.toLowerCase().search(`${value}`) ){ 
             
             this.returnItem =item ;
            }               
          })
        }
       
       console.log(this.returnItem) ; 
    } ,



  },
};
</script>

<style scoped>
.search {
  display: flex;
  flex-direction: row;
  margin: 10px;
  justify-content:center ;
  align-items: center;
}

input {
  width: 30vw;
  padding: 10px;
}

input[type="submit"] {
  width: 10vw ; 
}
 
.button-container > button {
  padding: 10px;
  margin: 10px;
}

.history {
  background-color: #ba4978;
}
</style>
